clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig3H_github.mat';

load(githubDataFileName);

figure;

subplot(2,1,1)
imagesc(timeForFrames,1:size(traceToPlot_RewardTrials,1),traceToPlot_RewardTrials, [-0.01 0.7]);
title('Response in Reward Trials')

subplot(2,1,2)
imagesc(timeForFrames,1:size(traceToPlot_ShockTrials,1),traceToPlot_ShockTrials, [-0.01 0.7]);
title('Response in Shock Trials')
