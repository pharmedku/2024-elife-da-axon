clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig4S1_github.mat';
load(githubDataFileName);

figure;
title(['Licking ']);
hold on;

plot(median_Licking_recallRate_group, 'x-', 'Color', [1, 0, 1]);
plot([1:4;1:4], [median_Licking_recallRate_group+SE_Licking_recallRate_group; ...
    median_Licking_recallRate_group-SE_Licking_recallRate_group], 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5 4.5], 'XTick', [1:4.5], 'XTickLabel', strsplit(['1st ', int2str(1:3)]), 'YLim', [45 100], 'YTick', [50:25:100], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

