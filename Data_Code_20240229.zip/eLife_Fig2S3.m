clear variables

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig2S3_github.mat';
load(githubDataFileName);

maxValue = 0.6;
minValue = -0.2;

figure;
for ii = 1:length(mouseData)
    subplot(2,4, ii);
    hold on;

    rewardResponses_thismouse = replaceMaxMin(mouseData(ii).rewardResponses, maxValue, minValue);
    shockResponses_thismouse = replaceMaxMin(mouseData(ii).shockResponses, maxValue, minValue);

    plot_with_max_min(rewardResponses_thismouse(mouseData(ii).rewardCellList), ...
        shockResponses_thismouse(mouseData(ii).rewardCellList), maxValue, minValue, [0,1,1]);
    plot_with_max_min(rewardResponses_thismouse(mouseData(ii).shockCellList), ...
        shockResponses_thismouse(mouseData(ii).shockCellList), maxValue, minValue, [1,0,1]);
    plot_with_max_min(rewardResponses_thismouse(mouseData(ii).nonResponseCellList), ...
        shockResponses_thismouse(mouseData(ii).nonResponseCellList), maxValue, minValue, [0.7,0.7,0.7]);

    %, 'Color', faceColors(axonType,:), 'MarkerSize', 12);
    axis([minValue maxValue minValue maxValue]);
    plot([minValue, maxValue], [0, 0], '-', 'Color', [0, 0, 0]);
    plot([0, 0], [minValue, maxValue],  '-', 'Color', [0, 0, 0]);
    plot([minValue, maxValue], [minValue, maxValue],  '-', 'Color', [0, 0, 0]);
    title(['Animal ', int2str(ii)], 'Color', [0, 0, 0]);
    axis square
end




function plot_with_max_min(xValues, yValues, maxValue, minValue, colorVector)

xToPlot = replaceMaxMin(xValues, maxValue, minValue);
yToPlot = replaceMaxMin(yValues, maxValue, minValue);
plot(xToPlot, yToPlot, '.', 'Color', colorVector);
end

%This function is only for display purpose, and not to be used for statstics.
function X = replaceMaxMin(X, maxValue, minValue)
X(X>maxValue) = maxValue;
X(X<minValue) = minValue;
end






