clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig2GHI_github.mat';

load(githubDataFileName);

figure;
subplot(3, 2, 1);
hold on;
plot(timeFrame, ROI1_Reward_signal, '-', 'Color', [0.9, 0.9, 0.9]);
plot(timeFrame, ROI1_RewardAve_signal([1, 3], :), '-', 'Color', [0.5, 0.5, 0.5]);
plot(timeFrame, ROI1_RewardAve_signal([2], :), '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-1.2, 3], 'XTick', [-1:3], ...
    'YLim', [-1, 2.2], 'YTick', [-2:2:4], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Axon 1');

subplot(3, 2, 2);
hold on;
plot(timeFrame, ROI1_Shock_signal, '-', 'Color', [0.9, 0.9, 0.9]);
plot(timeFrame, ROI1_ShockAve_signal([1, 3], :), '-', 'Color', [0.5, 0.5, 0.5]);
plot(timeFrame, ROI1_ShockAve_signal([2], :), '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-1.2, 3], 'XTick', [-1:3], ...
    'YLim', [-1, 2.2], 'YTick', [-2:2:4], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);


subplot(3, 2, 3);
hold on;
plot(timeFrame, ROI2_Reward_signal, '-', 'Color', [0.9, 0.9, 0.9]);
plot(timeFrame, ROI2_RewardAve_signal([1, 3], :), '-', 'Color', [0.5, 0.5, 0.5]);
plot(timeFrame, ROI2_RewardAve_signal([2], :), '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-1.2, 3], 'XTick', [-1:3], ...
    'YLim', [-1, 2.2], 'YTick', [-2:2:4], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Axon 2');

subplot(3, 2, 4);
hold on;
plot(timeFrame, ROI2_Shock_signal, '-', 'Color', [0.9, 0.9, 0.9]);
plot(timeFrame, ROI2_ShockAve_signal([1, 3], :), '-', 'Color', [0.5, 0.5, 0.5]);
plot(timeFrame, ROI2_ShockAve_signal([2], :), '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-1.2, 3], 'XTick', [-1:3], ...
    'YLim', [-1, 2.2], 'YTick', [-2:2:4], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);


subplot(3, 2, 5);
hold on;
plot(timeFrame, ROI3_Reward_signal, '-', 'Color', [0.9, 0.9, 0.9]);
plot(timeFrame, ROI3_RewardAve_signal([1, 3], :), '-', 'Color', [0.5, 0.5, 0.5]);
plot(timeFrame, ROI3_RewardAve_signal([2], :), '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-1.2, 3], 'XTick', [-1:3], ...
    'YLim', [-0.5, 2.2], 'YTick', [-2:2:4], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Axon 3');

subplot(3, 2, 6);
hold on;
plot(timeFrame, ROI3_Shock_signal, '-', 'Color', [0.9, 0.9, 0.9]);
plot(timeFrame, ROI3_ShockAve_signal([1, 3], :), '-', 'Color', [0.5, 0.5, 0.5]);
plot(timeFrame, ROI3_ShockAve_signal([2], :), '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-1.2, 3], 'XTick', [-1:3], ...
    'YLim', [-0.5, 2.2], 'YTick', [-2:2:4], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

