clear variables

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig2S2_github.mat';
load(githubDataFileName);

faceColors = [0,0,0; 0,1,1; 1,0,1; 0,0,0]; %black, cyan, red
faceColorsBG = [0.7,0.7,0.7; 0.7,1,1; 1,0.7,0.7; 0.7,0.7,0.7]; %black, cyan, red

figure('Name', 'Locomotion');
hold on;
for axonType = 1:3
    hold on;
    plot([1, 2], [preRunning_allROIs{axonType}; postRunning_allROIs{axonType}], 'Color', faceColorsBG(axonType,:));
end

for axonType = 1:3
    meanValues = mean([preRunning_allROIs{axonType}; postRunning_allROIs{axonType}], 2, 'omitnan');
    ste        = std([preRunning_allROIs{axonType}; postRunning_allROIs{axonType}], [], 2, 'omitnan')/sqrt(size(preRunning_allROIs{axonType},2));
    plot([1, 2], meanValues, 'Color', faceColors(axonType,:), 'LineWidth', 2);
    plot([1,2; 1,2], [meanValues+ste, meanValues-ste]', 'Color', faceColors(axonType,:));
end
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5, 2.5], 'XTick', [1, 2], 'XTickLabel', {'PreMove', 'PostMove'}, 'YLim', [-0.05, 0.3], 'YTick', [0:0.1:1], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
