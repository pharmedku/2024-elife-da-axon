clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig3IJKLMNS2S4_github.mat';
load(githubDataFileName)


%Fig 3I, J
axonTypeNames = {'nonResponse', 'Reward-prefeerring', 'Aversive-preferring', 'all        '};
faceColors = [0,0,0; 0,1,1; 1,0,1; 0,0,0]; %black, cyan, red
faceColorsBG = [0.7,0.7,0.7; 0.7,1,1; 1,0.7,0.7; 0.7,0.7,0.7]; %black, cyan, red
figure('Name', 'Fig3IJ');
%Plot CS Data
titleNames = {'CS 1st day', 'CS first third', 'CS second third', 'CS last third'};
for training_phase = 1:4
    h = subplot(4,2,training_phase*2-1);
    makeFiguresForScatterPlot(CS_rewardResponses(:,training_phase), CS_shockResponses(:,training_phase), ...
        titleNames{training_phase}, 'Response to reward cue', 'Response to shock cue', h, 1);
end
%Plot US Data
titleNames = {'US 1st day', 'US first third', 'US second third', 'US last third'};
for training_phase = 1:4
    h = subplot(4,2,training_phase*2);
    makeFiguresForScatterPlot(US_rewardResponses(:,training_phase), US_shockResponses(:,training_phase), ...
        titleNames{training_phase}, 'Response to reward', 'Response to shock', h, 1);
end



%Fig 3K Changes in US amplitude during Pavlovina
figure('Name', 'Fig3K');
hold on;
lineType = {'-', '-.'};
for axonType = 2:3
    plot(US_rewardMedianResponses(axonType,:), 'LineStyle', lineType{axonType-1}, 'Color', faceColors(axonType,:));
    plot([1:4;1:4], [US_rewardMedianResponses(axonType,:) + US_rewardSEResponses(axonType,:); US_rewardMedianResponses(axonType,:) - US_rewardSEResponses(axonType,:)], 'Color', faceColors(axonType,:));
    plot(US_shockMedianResponses(axonType,:),  'LineStyle', lineType{4-axonType}, 'Color', faceColors(axonType,:));
    plot([1:4;1:4], [US_shockMedianResponses(axonType,:) + US_shockSEResponses(axonType,:); US_shockMedianResponses(axonType,:) - US_shockSEResponses(axonType,:)], 'Color', faceColors(axonType,:));
end

set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5 4.5], 'XTick', 1:4,'XTickLabel', {'1st day', '1/3', '2/3', '3/3'}, ...
    'YLim', [-0.05, 0.25], 'YTick', [0:0.1:0.5], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
xlabel('behavioral session')
ylabel('response');
title('US response DF/F');


%Fig.3M Changes in CS response amplitude during Pavlovian
figure('Name', 'Fig3M');
hold on;
for axonType = 2:3
    plot(CS_rewardMedianResponses(axonType,:), 'LineStyle', lineType{axonType-1}, 'Color', faceColors(axonType,:));
    plot([1:4;1:4], [CS_rewardMedianResponses(axonType,:) + CS_rewardSEResponses(axonType,:); CS_rewardMedianResponses(axonType,:) - CS_rewardSEResponses(axonType,:)], 'Color', faceColors(axonType,:));
    plot(CS_shockMedianResponses(axonType,:),  'LineStyle', lineType{4-axonType}, 'Color', faceColors(axonType,:));
    plot([1:4;1:4], [CS_shockMedianResponses(axonType,:) + CS_shockSEResponses(axonType,:); CS_shockMedianResponses(axonType,:) - CS_shockSEResponses(axonType,:)], 'Color', faceColors(axonType,:));
end
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5 4.5], 'XTick', 1:4,'XTickLabel', {'1st day', '1/3', '2/3', '3/3'}, ...
    'YLim', [-0.05, 0.35], 'YTick', [0:0.1:0.5], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
xlabel('behavioral session')
ylabel('response');
title('CS: - shock trials, -. reward trials, magenta: aversive-axons, blue: reward-axons');


%Fig 3L, NPlot the change in polar angles during Pavlovian
figure('Name', 'Fig3L');
subplot(2,1,1);
hold on;
for axonType = [2, 3]
    plot(US_angleMeanResponses(axonType,:), '-.', 'Color', faceColors(axonType,:));
    plot([1:4;1:4], [US_angleMeanResponses(axonType,:) + US_angleSEResponses(axonType,:); US_angleMeanResponses(axonType,:) - US_angleSEResponses(axonType,:)], 'Color', faceColorsBG(axonType,:), 'LineWidth', 2);
end
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5 4.5], 'XTick', 1:4,'XTickLabel', {'1st day', '1/3', '2/3', '3/3'}, ...
    'YLim', [-15 100], 'YTick', [0:15:120], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Polar Angle:  US');

subplot(2,1,2);
hold on;
for axonType = [2, 3]
    plot(CS_angleMeanResponses(axonType,:), 'Color', faceColors(axonType,:));
    plot([1:4;1:4], [CS_angleMeanResponses(axonType,:) + CS_angleSEResponses(axonType,:); CS_angleMeanResponses(axonType,:) - CS_angleSEResponses(axonType,:)], 'Color', faceColorsBG(axonType,:), 'LineWidth', 2);
end
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5 4.5], 'XTick', 1:4,'XTickLabel', {'1st day', '1/3', '2/3', '3/3'}, ...
    'YLim', [-15 100], 'YTick', [0:15:120], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Polar Angle:  CS');

xlabel('behavioral session')
ylabel('Polar angle');




% Figure 3S4
figure('Name', 'Fig3S4');
h = subplot(2,2,1);
makeFiguresForScatterPlot(CS_rewardResponses_first(:,4), CS_rewardResponses_rest(:,4), ...
    'CS Reward within Session', 'Response to reward first', 'Response to reward rest', h, 0);
h = subplot(2,2,3);
makeFiguresForScatterPlot(CS_shockResponses_first(:,4), CS_shockResponses_rest(:,4), ...
    'CS Shock within Session', 'Response to shock first', 'Response to shock rest', h, 0);
h = subplot(2,2,2);
makeFiguresForScatterPlot(US_rewardResponses_first(:,4), US_rewardResponses_rest(:,4), ...
    'US Reward within Session', 'Response to reward first', 'Response to reward rest', h, 0);
h = subplot(2,2,4);
makeFiguresForScatterPlot(US_shockResponses_first(:,4), US_shockResponses_rest(:,4), ...
    'US Shock within Session', 'Response to shock first', 'Response to shock rest', h, 0);



%Figure 3S2
%%%  population data.
titleNames = {'CS 1st day', 'CS first third', 'CS second third', 'CS last third'};
colorValues = {[0, 1, 1], [1, 0 1]};
figure('Name', 'Fig 3S2');
for training_phase = 1:4
    for axonType = 2:3
        subplot(4,4,(3-axonType)*2+training_phase*4-3);
        hold on;
        plot(timeStampForFrames, CS_traceRewardResponses{axonType-1, training_phase}, 'Color', colorValues{axonType-1});
        if axonType == 3
            ylabel(titleNames{training_phase});
        end
        if training_phase == 1
            title([axonTypeNames{axonType}, ' axons']);
        end
        set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-2, 5], 'XTick', [-2:1:5], 'YLim', [-0.1, 0.4], 'YTick', [0:0.1:1], ...
            'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
        subplot(4,4,(3-axonType)*2+training_phase*4-2);
        plot(timeStampForFrames, CS_traceShockResponses{axonType-1, training_phase}, 'Color', colorValues{axonType-1});
        set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-2, 5], 'XTick', [-2:1:5], 'YLim', [-0.1, 0.4], 'YTick', [0:0.1:1], ...
            'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
    end
end








function makeFiguresForScatterPlot(Responses1, Responses2, titlename, xlabelname, ylabelname, h_axis, vectorMode)

axes(h_axis);
faceColors = [0.3,0.3,0.3; 0,1,1; 1,0,1;];
maxValue = 0.6;
displayMaxValue = 0.6;
minValue = -0.2;
tickValues = 0:0.5:1;

hold on;
for axonType = 1:3
    plot(replaceMaxMin(Responses1{axonType}, maxValue, minValue), replaceMaxMin(Responses2{axonType}, maxValue, minValue), '.', 'Color', faceColors(axonType,:), 'MarkerSize', 12);
    if vectorMode
        meanVector(axonType, :) = [mean(Responses1{axonType}), mean(Responses2{axonType})];
        plot([0, meanVector(axonType,1)], [0, meanVector(axonType,2)], '-', 'LineWidth', 3, 'Color', faceColors(axonType,:));
    end
end

axis([minValue displayMaxValue minValue displayMaxValue]);
plot([minValue, displayMaxValue], [0, 0], '-', 'Color', [0, 0, 0]);
plot([0, 0], [minValue, displayMaxValue],  '-', 'Color', [0, 0, 0]);
plot([minValue, displayMaxValue], [minValue, displayMaxValue],  '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [minValue, displayMaxValue], 'XTick', tickValues, 'YLim', [minValue, displayMaxValue], 'YTick', tickValues, ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title([titlename, ' ', 'scatterplot']);
xlabel(xlabelname); ylabel(ylabelname);
axis square
end


%For display purpose only
function X = replaceMaxMin(X, maxValue, minValue)
if maxValue == 0.2
    X(X>maxValue) = 0.25;
else
    X(X>maxValue) = maxValue;
end
X(X<minValue) = minValue;
end
