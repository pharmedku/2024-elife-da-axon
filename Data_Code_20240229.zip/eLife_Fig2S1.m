clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig2S1_github.mat';

load(githubDataFileName);

figure;
subplot(2,1,1);
plot((1:size(TonguePositions,1))/frameRate, -TonguePositions(:,1), '-', 'Color', [0,0,0]);
hold on;
plot([20, 80], [-1.5, -1.5], '-', 'Color', [0, 0, 0]);
plot([80, 80], [-0.5, -1.5], '-', 'Color', [0, 0, 0]);
rectangle('Position', [startTime, -1.5, endTime-startTime, 4.2], 'EdgeColor', [1,0,0]);
hold on;
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0 400], 'XTick', [0:50:10000], ...
    'YLim', [-2, 3], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

subplot(2,1,2)
plot((1:size(TonguePositions,1))/frameRate, -TonguePositions(:,1), '-', 'Color', [0,0,0]);
hold on;
plot([startTime+0.5, startTime+1.5], [-1.5, -1.5], '-', 'Color', [0, 0, 0]);
plot([startTime+1.5, startTime+1.5], [-0.5, -1.5], '-', 'Color', [0, 0, 0]);
hold on;
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [startTime endTime], 'XTick', [0:5:10000], ...
    'YLim', [-2 3], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

