clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig4S2_github.mat';

load(githubDataFileName);

figure;
hold on;
colorMap = [0,0.67,0.33; 0,0.33,0.67;0,0,1.0];
for ii = 1:3
    plot((FrameForPlot(:,1)-100)/60, RecallRateForPlot_group(:,ii), 'Color', colorMap(ii,:), 'LineWidth', ii/2);
end
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-1.5, 3.5], 'XTick', [-2:1:4], ...
    'YLim', [30, 100], 'YTick', [50:25:100], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title(['green:first 1/3, blue: last 1/3']);
xlabel(['time from cue onset']);
ylabel(['Performance']);

