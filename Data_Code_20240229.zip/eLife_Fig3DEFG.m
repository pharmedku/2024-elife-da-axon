clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig3DEFG_github.mat';

load(githubDataFileName);
tmp = load(githubDataFileName);
disp(tmp);

figure;
set(gcf, 'Name', 'Anticipatory Licking/Running', 'Color', [1 1 1], 'Units', 'centimeters', 'Position', [2 2 22 20]);

subplot(2,1,1);
hold on;
plot(median_Licking_Reward, 'x-', 'Color', [0, 0, 1]);
plot([1:4;1:4], [median_Licking_Reward+SE_Licking_Reward; median_Licking_Reward-SE_Licking_Reward], 'Color', [0, 0, 0]);

plot(median_Licking_Punish, 'x-', 'Color', [1, 0, 0]);
plot([1:4;1:4], [median_Licking_Punish+SE_Licking_Punish; median_Licking_Punish-SE_Licking_Punish], 'Color', [0, 0, 1]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5 4.5], 'XTick', [1:4], 'XTickLabel', strsplit(['1st ', int2str(1:3)]), ...
    'YLim', [-1 5], 'YTick', [0:2:4], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Licking rate');

subplot(2,1,2);
hold on;
plot(median(Running_Reward_Rate,1), 'x-', 'Color', [0, 0, 1]);
plot([1:4;1:4], [median_Running_Reward+SE_Running_Reward; median_Running_Reward-SE_Running_Reward], 'Color', [0, 0, 0]);

plot(median(Running_Punish_Rate,1), 'x-', 'Color', [1, 0, 0]);
plot([1:4;1:4], [median_Running_Punish+SE_Running_Punish; median_Running_Punish-SE_Running_Punish], 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5 4.5], 'XTick', [1:4], 'XTickLabel', strsplit(['1st ', int2str(1:3)]), ...
    'YLim', [-1, 2.2], 'YTick', [0:1:2], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Running rate');




