clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig3S3_github.mat';

load(githubDataFileName);
faceColors = [0,1,1]; %black, cyan, red
faceColorsBG = [0.7,1,1;]; %black, cyan, red

figure('Name', 'Baseline vs. Omission');
hold on;
plot([1, 2], [baselineRewardResponses_eachROI; responseRewardResponses_eachROI], 'Color', faceColorsBG);
plot([1, 2], meanValuesForRewardResponses, 'Color', [0, 1, 1], 'LineWidth', 2);
plot([1,2; 1,2], [meanValuesForRewardResponses+steValuesForRewardResponses, meanValuesForRewardResponses-steValuesForRewardResponses]', 'Color', [0, 1, 1]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0.5, 2.5], 'XTick', [1, 2], 'XTickLabel', {'Baseline', 'Omission'}, 'YLim', [-0.05, 0.15], 'YTick', [0:0.1:1], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

figure('Name', 'Omission');
hold on;
plot(timeStampForOmission, traceRewardOmissionResponses, 'Color', faceColors*0.7, 'LineWidth', 2);
plot([-5, 2], [traceBaseline_mean-2*traceBaseline_std, traceBaseline_mean+2*traceBaseline_std; traceBaseline_mean-2*traceBaseline_std, traceBaseline_mean+2*traceBaseline_std], ...
    'Color', faceColors*0.7, 'LineWidth',1);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-5, 2], 'XTick', [-5:1:2], 'YLim', [-0.05, 0.22], 'YTick', [0:0.05:1], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);

