clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig2S4_github.mat';

load(githubDataFileName);

figure; title('Reward Multivolume'); hold on;
plot(rewardDurations, rewardData(:,~rewardCellType), 'Color', [0.8,0.8,0.8], 'LineWidth', 1.5);
plot(rewardDurations, rewardData(:,rewardCellType), 'Color', [0,0,0], 'LineWidth', 1.5);

medianData = median(rewardData, 2)';
stdData    = std(rewardData, 0, 2)';
plot(rewardDurations, medianData, 'LineWidth', 5, 'color', [0,1,1]);
plot([rewardDurations; rewardDurations], [medianData-stdData/sqrt(size(rewardData,2));  medianData+stdData/sqrt(size(rewardData,2))], ...
    'LineWidth', 3, 'color', [0,1,1]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-2, 17], 'XTick', [0:5:20], 'YLim', [-7 17], 'YTick', [0:5:15], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);


figure; title('Shock Multivolume'); hold on;
plot(shockAmplitudes, shockData(:,~shockCellType), 'Color', [0.8,0.8,0.8], 'LineWidth', 1.5);
plot(shockAmplitudes, shockData(:,shockCellType), 'Color', [0,0,0], 'LineWidth', 1.5);
axis([-0.1, 0.5, -0.1, 0.3]);

medianData = median(shockData, 2)';
stdData    = std(shockData, 0, 2)';
plot(shockAmplitudes, medianData, 'LineWidth', 5, 'color', [1,0,1]);
plot([shockAmplitudes; shockAmplitudes], [medianData-stdData/sqrt(size(shockData,2));  medianData+stdData/sqrt(size(shockData,2))], ...
    'LineWidth', 3, 'color', [1,0,1]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-0.1, 0.5], 'XTick', [0:0.2:0.4], 'YLim', [-30 65], 'YTick', [0:20:60], ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
