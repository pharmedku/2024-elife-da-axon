clear variables

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig2JK_github.mat';

load(githubDataFileName);

%display in plots
range_polar = [-15:7.5:105]-7.5/2;
faceColors = [0.6,0.6,0.6; 0,1,1; 1,0,1; ];
maxValue = 0.6;
minValue = -0.2;
tickValues = 0:0.5:1;

figure;
hold on;
meanVector = NaN(3,2);
for axonType = 1:3
    plot(replaceMaxMin(rewardResponses{axonType}, maxValue, minValue), replaceMaxMin(shockResponses{axonType}, maxValue, minValue), '.', 'Color', faceColors(axonType,:), 'MarkerSize', 12);
    meanVector(axonType, :) = [mean(rewardResponses{axonType}), mean(shockResponses{axonType})];
    plot([0, meanVector(axonType,1)], [0, meanVector(axonType,2)], '-', 'LineWidth', 3, 'Color', faceColors(axonType,:));
end
axis([minValue maxValue minValue maxValue]);
plot([minValue, maxValue], [0, 0], '-', 'Color', [0, 0, 0]);
plot([0, 0], [minValue, maxValue],  '-', 'Color', [0, 0, 0]);
plot([minValue, maxValue], [minValue, maxValue],  '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [minValue, maxValue], 'XTick', tickValues, 'YLim', [minValue, maxValue], 'YTick', tickValues, ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title(['reward DF/F vs. aversive DF/F', ' ', 'scatterplot']);
xlabel('Reward DF/F'); ylabel('Aversive DF/F');
axis square

figure;
title('Polar angle'); hold on;
totalAxonNumber = sum(cellfun(@(x) length(x), rewardResponses));
count_EachAxonType=NaN(3,length(range_polar));
for axonType=1:3
    [count_EachAxonType(axonType,:),center] = hist(replaceMaxMin(cart2pol(rewardResponses{axonType}, shockResponses{axonType})/pi*180, range_polar(end), range_polar(1)), range_polar);
end
h_bar = bar(range_polar, count_EachAxonType([3,2,1],:)/totalAxonNumber, 'stack');
for axonType = 1:3
    set(h_bar(axonType==[3,2,1]), 'FaceColor', faceColors(axonType,:), 'EdgeColor', [0 0 0]);
end

tmp = cart2pol([rewardResponses{2:3}],[shockResponses{2:3}])/pi*180;
[f,xi] = ksdensity(tmp);
plot(xi, f*7.5*sum(cellfun(@(x) length(x), rewardResponses(2:3)))/sum(cellfun(@(x) length(x), rewardResponses(1:3))), 'Color', [0, 0, 0]);


set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [min(range_polar)-15, max(range_polar)+15], 'XTick', [-45:45:135], ...
    'YLim', [0, 0.25], 'YTick', [0:0.1:0.3], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
hold on;



%This function is only for display purpose, and not to be used for statstics.
function X = replaceMaxMin(X, maxValue, minValue)
X(X>maxValue) = maxValue;
X(X<minValue) = minValue;
end






