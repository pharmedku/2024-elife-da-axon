clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig1S1_github.mat';

load(githubDataFileName);
figure;
semilogy([1, 2], [CP;PR], '-', 'Color', [0,0,0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0, 3], 'XTick', [1, 2], 'XTickLabel', {'Caudoputamen', 'Prelimibic layer 1'},...
    'YLim', [10^-4/2, 2], 'YTick', [10^-4, 10^-3, 10^-2, 10^-1, 1], 'YtickLabel', [0.0001, 0.001, 0.01, 0.1, 1], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
