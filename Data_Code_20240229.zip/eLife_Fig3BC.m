clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig3BC_github.mat';

load(githubDataFileName)

figure;
subplot(2,2,1);
imagesc([-5, 5], 1:12, LickingPattern_Reward, [0, 0.2]);
colormap(pink);
title(['Lick Reward - day']);

subplot(2,2,2);
imagesc([-5, 5], 1:12, LickingPattern_Shock, [0, 0.2]);
colormap(pink);
title(['Lick Shock - day']);

subplot(2,2,3);
imagesc([-5, 5], 1:12, RunningPattern_Reward, [0, 1]);
colormap(pink);
title(['Run Reward - day']);

subplot(2,2,4);
imagesc([-5, 5], 1:12, RunningPattern_Shock, [0, 1]);
colormap(pink);
title(['Run Shock - day']);


