clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig4BCDE_github.mat';

load(githubDataFileName);
faceColors = [0,0,0; 0,1,1; 1,0,0;]; %black, cyan, red
correctRowID = 1;
errorRowID =2;

for networkNameCell = {'Lick', 'ResNet'}
    networkName = char(networkNameCell);
    disp(['Network = ', networkName]);
    switch networkName
        case 'Lick'
            deltaRewardResponses_eachROI = Lick_deltaRewardResponses_eachROI;
            deltaShockResponses_eachROI = Lick_deltaShockResponses_eachROI;
        case 'ResNet'
            deltaRewardResponses_eachROI = ResNet_deltaRewardResponses_eachROI;
            deltaShockResponses_eachROI = ResNet_deltaShockResponses_eachROI;
    end
    figure('Name', networkName);
    h = subplot(2,2,1);
    makeFiguresForScatterPlot({deltaRewardResponses_eachROI{1}(correctRowID,:), deltaRewardResponses_eachROI{2}(correctRowID,:), deltaRewardResponses_eachROI{3}(correctRowID,:)}, ...
        {deltaRewardResponses_eachROI{1}(errorRowID,:), deltaRewardResponses_eachROI{2}(errorRowID,:), deltaRewardResponses_eachROI{3}(errorRowID,:)}, ...
        [networkName, ' ', 'Late', ' Responses in Reward trials'], 'Correct trials', 'Error trials', 0.2, h);

    h = subplot(2,2,2);
    makeFiguresForScatterPlot({deltaShockResponses_eachROI{1}(correctRowID,:), deltaShockResponses_eachROI{2}(correctRowID,:), deltaShockResponses_eachROI{3}(correctRowID,:)}, ...
        {deltaShockResponses_eachROI{1}(errorRowID,:), deltaShockResponses_eachROI{2}(errorRowID,:), deltaShockResponses_eachROI{3}(errorRowID,:)}, ...
        [networkName, ' ', 'Late', ' Responses in Shock trials'], 'Correct trials', 'Error trials', 0.6, h);

    h = subplot(2,2,3);
    makeFiguresForScatterPlot({deltaRewardResponses_eachROI{1}(correctRowID,:), deltaRewardResponses_eachROI{2}(correctRowID,:), deltaRewardResponses_eachROI{3}(correctRowID,:)}, ...
        {deltaShockResponses_eachROI{1}(correctRowID,:), deltaShockResponses_eachROI{2}(correctRowID,:), deltaShockResponses_eachROI{3}(correctRowID,:)}, ...
        [networkName, ' ', 'Late', ' Responses in correct trials'], 'Response to Reward', 'Response to Shock', 0.6, h);

    h = subplot(2,2,4);
    makeFiguresForScatterPlot({deltaRewardResponses_eachROI{1}(errorRowID,:), deltaRewardResponses_eachROI{2}(errorRowID,:), deltaRewardResponses_eachROI{3}(errorRowID,:)}, ...
        {deltaShockResponses_eachROI{1}(errorRowID,:), deltaShockResponses_eachROI{2}(errorRowID,:), deltaShockResponses_eachROI{3}(errorRowID,:)}, ...
        [networkName, ' ', 'Late', ' Responses in error trials'], 'Response to Reward', 'Response to Shock', 0.6, h);

end

disp('');


function makeFiguresForScatterPlot(Responses1, Responses2, titlename, xlabelname, ylabelname, maxValue, h_axis)

faceColors = [0.3,0.3,0.3; 0,1,1; 1,0,1;];
switch maxValue
    case 0.6
        displayMaxValue = 0.6;
        minValue = -0.2;
        tickValues = 0:0.5:1;
    case 0.2
        maxValue = 0.2;
        displayMaxValue = 0.25;
        minValue = -0.15;
        tickValues = -0.1:0.1:maxValue;
end
axes(h_axis);
hold on;
for axonType = 1:3
    plot(replaceMaxMin(Responses1{axonType}, maxValue, minValue), replaceMaxMin(Responses2{axonType}, maxValue, minValue), '.', 'Color', faceColors(axonType,:), 'MarkerSize', 12);
end
axis([minValue displayMaxValue minValue displayMaxValue]);
plot([minValue, displayMaxValue], [0, 0], '-', 'Color', [0, 0, 0]);
plot([0, 0], [minValue, displayMaxValue],  '-', 'Color', [0, 0, 0]);
plot([minValue, displayMaxValue], [minValue, displayMaxValue],  '-', 'Color', [0, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [minValue, displayMaxValue], 'XTick', tickValues, 'YLim', [minValue, displayMaxValue], 'YTick', tickValues, ...
    'LineWidth', 0.5, 'TickLength', [0.02 0.025], 'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title([titlename, ' ', 'scatterplot']);
xlabel(xlabelname); ylabel(ylabelname);
axis square
end


%For display purpose only
function X = replaceMaxMin(X, maxValue, minValue)
if maxValue == 0.2
    X(X>maxValue) = 0.25;
else
    X(X>maxValue) = maxValue;
end
X(X<minValue) = minValue;
end
