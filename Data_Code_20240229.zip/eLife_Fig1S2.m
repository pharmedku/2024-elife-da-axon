clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig1S2_github.mat';

load(githubDataFileName);

figure;
subplot(2,1,1)
plot(standard_FrameNo, standard_shift, '-', 'Color', [0, 0, 0]);
hold on;
plot(standard_event_Frame, 60, '.', 'Color', [1, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-10000, 200000], 'XTick', [0:100000:200000],...
    'YLim', [-5, 65], 'YTick', [0:20:60], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);


subplot(2,1,2)
plot(extra_FrameNo, extra_shift, '-', 'Color', [0, 0, 0]);
hold on;
if ~isempty(extra_event_Frame)
    plot(extra_event_Frame, 16, '.', 'Color', [1, 0, 0]);
end
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [-10000, 200000], 'XTick', [0:100000:200000],...
    'YLim', [-5, 65], 'YTick', [0:20:60], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);


figure;
subplot(2,2,1);
plot(1,standard_Event_1st, '.', 'Color', [0, 0, 0]); hold on;
plot(2,extra_Event_1st, '.', 'Color', [1, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0, 3], 'XTick', [1, 2],...
    'YLim', [-0.1,1.6], 'YTick', [0:0.5:1.5], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Event Initial half');

subplot(2,2,2);
plot(1,standard_Event_2nd, '.', 'Color', [0, 0, 0]); hold on;
plot(2,extra_Event_2nd, '.', 'Color', [1, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0, 3], 'XTick', [1, 2],...
    'YLim', [-0.1,1.6], 'YTick', [0:0.5:1.5], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('Event Latter half');


subplot(2,2,3);
plot(1,standard_RMS_1st, '.', 'Color', [0, 0, 0]); hold on;
plot(2,extra_RMS_1st, '.', 'Color', [1, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0, 3], 'XTick', [1, 2],...
    'YLim', [-1, 20], 'YTick', [0:10:20], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('RMS Initial half');

subplot(2,2,4);
plot(1,standard_RMS_2nd, '.', 'Color', [0, 0, 0]); hold on;
plot(2,extra_RMS_2nd, '.', 'Color', [1, 0, 0]);
set(gca, 'Xgrid', 'off', 'Ygrid', 'off', 'XLim', [0, 3], 'XTick', [1, 2],...
    'YLim', [-1, 20], 'YTick', [0:10:20], 'LineWidth', 0.5, 'TickLength', [0.02 0.025], ...
    'TickDir', 'out', 'Box', 'off', 'FontName', 'Arial', 'FontSize', 8);
title('RMS Latter half');


