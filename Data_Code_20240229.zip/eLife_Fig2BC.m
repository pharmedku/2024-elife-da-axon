clear all;

githubDataFileName = 'C:\Users\Sato Lab\Desktop\Analysis_DA\Data\DataForFig2BC_github.mat';

load(githubDataFileName);

figure;
subplot(4,1,1);
plot(timeStamp_licking, lickPattern+5, 'Color', [0, 0, 0]);
hold on;
plot(timeStamp_running, runningPattern, 'Color', [0, 0, 0])

plot([timeRewardStart; timeRewardStart], [-1, 9], '-', 'Color', [0,0,1])
plot([timePunishStart; timePunishStart], [-1, 9], '-', 'Color', [1,0,0])

axis([-Inf Inf -1 9])




subplot(4,1,2);
hold on;
plot(timeStamp_DLC, meanRewardDLCData, 'Color', [0,0,1]);
plot(timeStamp_DLC, meanRewardDLCData+steRewardDLCData, 'Color', [0.5,0.5,1]);
plot(timeStamp_DLC, meanRewardDLCData-steRewardDLCData, 'Color', [0.5,0.5,1]);
plot(timeStamp_DLC, meanShockDLCData, 'Color', [1,0,0]);
plot(timeStamp_DLC, meanShockDLCData+steShockDLCData, 'Color', [1,0.5,0.5]);
plot(timeStamp_DLC, meanShockDLCData-steShockDLCData, 'Color', [1,0.5,0.5]);
axis([-3.5, 3.5, -Inf, Inf]);


subplot(4,1,3);
hold on;
plot(timeStamp_Treadmill, meanRewardTreadmillData, 'Color', [0,0,1]);
plot(timeStamp_Treadmill, meanRewardTreadmillData+steRewardTreadmillData, 'Color', [0.5, 0.5,1]);
plot(timeStamp_Treadmill, meanRewardTreadmillData-steRewardTreadmillData, 'Color', [0.5, 0.5,1]);
plot(timeStamp_Treadmill, meanShockTreadmillData, 'Color', [1,0,0]);
plot(timeStamp_Treadmill, meanShockTreadmillData+steShockTreadmillData, 'Color', [1,0.5,0.5]);
plot(timeStamp_Treadmill, meanShockTreadmillData-steShockTreadmillData, 'Color', [1,0.5,0.5]);
axis([-3.5, 3.5, -Inf, Inf]);
